package https://impact-fhir.mitre.org/r4/ImplementationGuide/impact-fhir;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class StandardForm {

}
