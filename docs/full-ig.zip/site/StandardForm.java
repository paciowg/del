package https://impact-fhir.mitre.org/r4/ImplementationGuide/impact-fhir-0.0.1;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class StandardForm {

}
